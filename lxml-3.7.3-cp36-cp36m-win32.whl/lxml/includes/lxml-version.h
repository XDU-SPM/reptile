#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "3.7.3"
#endif
